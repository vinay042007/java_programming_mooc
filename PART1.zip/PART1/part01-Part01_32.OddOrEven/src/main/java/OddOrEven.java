import java.util.Scanner;

public class OddOrEven {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Write your program here 
        System.out.println("Give a number:");
        int n = scan.nextInt();
        
        if (n % 2 == 0) {
            System.out.println("Number " + n + " is even.");
        } else { // Fixed line 27: '}' and 'else' are now on the same line
            System.out.println("Number " + n + " is odd.");
        }
    }
}
