
import java.util.Scanner;

public class DifferentTypesOfInput {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        // Prompt for and read String
        System.out.println("Give a string:");
        String text = scanner.nextLine();

        // Prompt for and read integer
        System.out.println("Give an integer:");
        int integer = Integer.valueOf(scanner.nextLine());

        // Prompt for and read double
        System.out.println("Give a double:");
        double floatingPoint = Double.valueOf(scanner.nextLine());

        // Prompt for and read boolean
        System.out.println("Give a boolean:");
        boolean trueOrFalse = Boolean.valueOf(scanner.nextLine());

        // Print the inputs back to the user
        System.out.println("You gave the string " + text);
        System.out.println("You gave the integer " + integer);
        System.out.println("You gave the double " + floatingPoint);
        System.out.println("You gave the boolean " + trueOrFalse);

    }
}
